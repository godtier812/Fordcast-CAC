"""Decode the complete export and write local delivery checks."""
import sys,json,subprocess,hashlib,re,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path.insert(0,str(R.parent/'video-tools'))
import av,imageio_ffmpeg
from PIL import Image,ImageDraw
O=R/'output';video=O/'FordCast_Demo_1080p.mp4';ff=imageio_ffmpeg.get_ffmpeg_exe()
c=av.open(str(video));v=c.streams.video[0];a=c.streams.audio[0]
report={'file':video.name,'duration_seconds':c.duration/av.time_base,'width':v.width,'height':v.height,'fps':float(v.average_rate),'video_codec':v.codec_context.name,'audio_codec':a.codec_context.name,'sample_rate':a.codec_context.sample_rate,'metadata':dict(c.metadata),'sha256':hashlib.sha256(video.read_bytes()).hexdigest()}
c.close()
assert report['width']==1920 and report['height']==1080 and report['fps']==30
assert abs(report['duration_seconds']-165)<.1
assert not any('location' in k.lower() or 'creation' in k.lower() for k in report['metadata'])
p=subprocess.run([ff,'-hide_banner','-v','error','-i',str(video),'-f','null','-'],capture_output=True,text=True)
report['full_decode_passed']=p.returncode==0 and not p.stderr.strip();report['decode_errors']=p.stderr
assert report['full_decode_passed'],p.stderr
p=subprocess.run([ff,'-hide_banner','-i',str(video),'-vn','-af','ebur128=peak=true','-f','null','-'],capture_output=True,text=True)
(O/'audio-analysis.txt').write_text(p.stderr,encoding='utf-8');report['audio_analysis']=p.stderr[p.stderr.rfind('Summary:'):]
times=[2,14,33,42,57,70,83,96,111,126,140,150,160]
sheet=Image.new('RGB',(1280,2520),'#0B111B');d=ImageDraw.Draw(sheet)
for i,t in enumerate(times):
    path=O/f'final-frame-{i+1:02}.jpg'
    subprocess.run([ff,'-v','error','-y','-ss',str(t),'-i',str(video),'-frames:v','1','-q:v','2',str(path)],check=True)
    im=Image.open(path);im.thumbnail((640,360));x=(i%2)*640;y=(i//2)*360;sheet.paste(im,(x,y));d.text((x+5,y+5),f'{t}s',fill='white')
sheet.save(O/'final-contact-sheet.jpg',quality=92)
(O/'QA.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
# Include prepared scenes and narration rather than thousands of intermediate capture frames.
with zipfile.ZipFile(O/'FordCast_Edit_Package.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=4) as z:
    for name in ['produce.py','verify_export.py','timeline.json','transcripts.json','media.json','captions.ass']:
        z.write(R/name,name)
    for p in (R/'scenes').iterdir():
        if p.suffix=='.png' or (p.suffix=='.mp4' and not p.name.startswith('part-')):
            z.write(p,'scenes/'+p.name)
    for name in ['narration-master.wav','FordCast_Captions.srt','CREDITS.md','README.md','EDIT_NOTES.md','QA.json']:
        z.write(O/name,'output/'+name)
print(json.dumps(report,indent=2))
print('Editable package created',flush=True)
