"""Reproducible local video edit. Original personal media never leaves this machine."""
import sys, json, math, subprocess, re, textwrap, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[1]
sys.path.insert(0,str(REPO/'.local/video-tools'))
import imageio_ffmpeg
from PIL import Image, ImageDraw, ImageFont, ImageOps
FF=imageio_ffmpeg.get_ffmpeg_exe()
CAP=ROOT/'captures'; SC=ROOT/'scenes'; SRC=ROOT/'source'; OUT=ROOT/'output'
OUT.mkdir(exist_ok=True)
W,H,FPS=1920,1080,30
BG='#0B111B'; FG='#EAF2FA'; MUTED='#A9BBD0'; CYAN='#36D5D1'; LINE='#25354B'; AMBER='#F4B655'
FONT=Path('C:/Windows/Fonts/segoeui.ttf'); BOLD=Path('C:/Windows/Fonts/seguisb.ttf'); MONO=Path('C:/Windows/Fonts/consola.ttf')
font=lambda n,b=False,m=False:ImageFont.truetype(str(MONO if m else BOLD if b else FONT),n)

def run(args, log='encode.log'):
    args=[*args[:-1],'-map_metadata','-1','-map_chapters','-1',args[-1]]
    with open(ROOT/log,'a',encoding='utf-8') as f:
        p=subprocess.run([FF,'-hide_banner','-y',*map(str,args)],stdout=f,stderr=f)
    if p.returncode: raise RuntimeError(f'FFmpeg failed ({p.returncode}); see {log}')

def wrapped(draw,text,x,y,width,size=42,fill=FG,bold=False,leading=1.25):
    f=font(size,bold); words=text.split(); line=''
    for word in words:
        candidate=(line+' '+word).strip()
        if line and draw.textlength(candidate,font=f)>width:
            draw.text((x,y),line,font=f,fill=fill); y+=int(size*leading); line=word
        else: line=candidate
    if line: draw.text((x,y),line,font=f,fill=fill);y+=int(size*leading)
    return y

titles={1:'Check the crossings\non your trip.',2:'A local problem.\nA pre-trip check.',3:'One trip.\nCrossings in context.',4:'Evidence, with the\ngaps still visible.',5:'Count crossing areas,\nnot flasher arms.',6:'Test the decision.\nKeep the test separate.',7:'English / Español',8:'An archived storm.\nA simulated decision.',9:'No future readings\nin a historical test.',10:'A gauge-reference study.\nNot road-flood accuracy.',11:'Tools, assistance\nand student contributions.',12:'Check before you leave.'}
kickers={1:'MEET FORDCAST',2:'CENTRAL TEXAS CONTEXT',3:'CURRENT TRIP CHECK',4:'REPORTS · READINGS · HISTORY',5:'IMPLEMENTATION · TYPESCRIPT',6:'TEST INPUT · SIMULATED CLOSURE',7:'BILINGUAL BROWSER INTERFACE',8:'ARCHIVED SIMULATION · MAY 2015',9:'IMPLEMENTATION · PYTHON',10:'LEAVE-ONE-STORM-OUT EVALUATION',11:'AUTHORSHIP & DISCLOSURE',12:'WHAT COMES NEXT'}

def base(n,phone=True,title=None):
    im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
    d.text((64,26),'FordCast',font=font(39,True),fill=FG)
    d.text((1550,39),f'{n:02d} / 12',font=font(23,False,True),fill=MUTED)
    d.line((64,99,1856,99),fill=LINE,width=2)
    x=620 if phone else 90
    d.text((x,145),kickers[n],font=font(22,True),fill=AMBER if n in [6,8,10] else CYAN)
    yy=195
    for line in (title or titles[n]).split('\n'):
        d.text((x,yy),line,font=font(58,True),fill=FG);yy+=70
    d.rectangle((0,952,1920,1080),fill='#070C13')
    d.line((64,951,1856,951),fill=LINE,width=1)
    d.text((64,923),'FordCast web demonstration · GPS off',font=font(17),fill=MUTED)
    return im

def image_fit(im,path,box,cover=False):
    p=Image.open(path).convert('RGB'); x,y,w,h=box
    p=ImageOps.fit(p,(w,h),method=Image.Resampling.LANCZOS) if cover else ImageOps.contain(p,(w,h),Image.Resampling.LANCZOS)
    im.paste(p,(x+(w-p.width)//2,y+(h-p.height)//2))

PHONE=(134,130,364,789)
def phone_image(im,name): image_fit(im,CAP/f'{name}.jpg',PHONE)
def crop_image(im,name,source_box,box):
    p=Image.open(CAP/f'{name}.jpg').convert('RGB').crop(source_box)
    p=ImageOps.contain(p,(box[2],box[3]),Image.Resampling.LANCZOS)
    im.paste(p,(box[0]+(box[2]-p.width)//2,box[1]))

def credit(im,text):
    d=ImageDraw.Draw(im);d.rectangle((610,905,1860,950),fill=BG);d.text((620,922),text,font=font(16),fill=MUTED)

def savecard(im,name):
    path=SC/f'{name}.png';im.save(path);return path

def cards():
    im=base(1);phone_image(im,'01-map');d=ImageDraw.Draw(im)
    wrapped(d,'A bilingual trip checker for Central Texas drivers.',620,410,1110,43,MUTED)
    wrapped(d,'Official reports. Available readings. Explicit unknowns.',620,580,1050,36,CYAN)
    savecard(im,'01-map-card')
    im=base(1,False,title='FordCast\nCheck the crossings on your trip.');d=ImageDraw.Draw(im)
    wrapped(d,'A Central Texas student project',90,465,780,34,MUTED)
    d.text((90,550),'Ashrith Repaka',font=font(39,True),fill=FG)
    d.text((90,607),'Ayush Sankar',font=font(39,True),fill=FG)
    savecard(im,'01-intro-base')

    im=base(2,False,title='Texas Colorado River\nLake Austin');d=ImageDraw.Draw(im)
    image_fit(im,CAP/'02-lake-austin-map.jpg',(90,370,1000,525),True)
    image_fit(im,SRC/'pennybacker-public-domain.jpg',(1130,390,700,455),True)
    d.text((1130,850),'Pennybacker Bridge · Lake Austin',font=font(25,True),fill=FG)
    credit(im,'Map: © OpenStreetMap contributors · Photo: Dbtfz (2005), public domain; cropped')
    savecard(im,'02-context')
    im=base(2,False,title='July 5, 2025\nA dated waterway-use restriction.');d=ImageDraw.Draw(im)
    notice=Image.open(CAP/'02-city-notice-full.jpg').convert('RGB').crop((250,740,1040,1200))
    notice.thumbnail((1000,520),Image.Resampling.LANCZOS);im.paste(notice,(90,370))
    wrapped(d,'LOCAL CONTEXT',1040,420,760,28,CYAN,True)
    wrapped(d,'Swift water and debris prompted restrictions.',1040,475,760,42,FG,True)
    wrapped(d,'This notice concerns waterway use. The following Onion Creek road trip is a separate demonstration.',1040,650,760,30,MUTED)
    credit(im,'Source: City of Austin · austintexas.gov · July 5, 2025 (headline excerpt)')
    savecard(im,'02-notice')
    im=base(2);phone_image(im,'01-map');d=ImageDraw.Draw(im)
    wrapped(d,'Check road crossings before leaving.',620,410,1050,48,CYAN,True)
    wrapped(d,'The river context does not establish that the roads on this trip flooded.',620,570,1080,35,MUTED)
    savecard(im,'02-app')

    im=base(3);d=ImageDraw.Draw(im)
    wrapped(d,'Downtown Austin → Onion Creek Park',620,420,1150,45,CYAN,True)
    d.text((620,580),'2,052',font=font(104,True),fill=FG)
    wrapped(d,'inventory records',620,700,1100,38,MUTED)
    wrapped(d,'Inventory records ≠ monitored roads',620,795,1120,31,AMBER,True)
    credit(im,'Live trip capture · idle network waiting may be trimmed')
    savecard(im,'03-base')

    for phase,src,crop in [('evidence','04-evidence',(25,450,367,627)),('groups','04-groups',(24,309,367,595))]:
        im=base(4);phone_image(im,src);d=ImageDraw.Draw(im)
        crop_image(im,src,crop,(620,390,1150,440))
        wrapped(d,'Actual app evidence, enlarged',620,850,1150,25,MUTED)
        savecard(im,f'04-{phase}')

    def codecard(n,path,start,end,highlight,name):
        im=base(n,False);d=ImageDraw.Draw(im)
        lines=path.read_text(encoding='utf-8').splitlines()
        d.rounded_rectangle((90,365,1830,850),radius=10,fill='#111C2B',outline=LINE,width=2)
        d.text((120,382),str(path.relative_to(REPO)).replace('\\','/'),font=font(23,False,True),fill=MUTED)
        f=font(25,False,True);yy=437
        for no in range(start,end+1):
            if no in highlight:d.rectangle((108,yy-2,1814,yy+35),fill='#183D48')
            d.text((119,yy),f'{no:>3}',font=f,fill='#7890AA')
            line=lines[no-1];d.text((190,yy),line,font=f,fill=FG)
            yy+=39
        if n==9 and name in ('09-available','09-observation'):
            token='r.available_at > as_of' if name=='09-available' else 'r.obs_time > as_of'
            line=lines[start+1];prefix=line[:line.index(token)];xx=190+d.textlength(prefix,font=f);yy=437+2*39
            d.rectangle((xx-2,yy-2,xx+d.textlength(token,font=f)+2,yy+35),fill='#176070')
            d.text((xx,yy),token,font=f,fill=FG)
        d.text((100,874),'Actual repository source · highlighting added for explanation',font=font(21),fill=MUTED)
        if n==9: d.text((1010,874),'Delivery delay is an assumption.',font=font(23,True),fill=AMBER)
        return savecard(im,name)
    danger=REPO/'mobile/src/lib/danger.ts';lines=danger.read_text(encoding='utf-8').splitlines()
    road=next(i+1 for i,s in enumerate(lines) if 'g.stem.length < 4' in s)
    creek=road+1;dist=next(i+1 for i,s in enumerate(lines) if 'return distanceKm(g.records[0]!, status)' in s)
    for key,hi in [('road',[road]),('waterway',[creek]),('distance',[dist])]:codecard(5,danger,road,dist,hi,'05-'+key)
    py=REPO/'backend/fordcast/sources/base.py';lines=py.read_text().splitlines();fn=next(i+1 for i,s in enumerate(lines) if s.startswith('def assert_no_lookahead'))
    codecard(9,py,fn,fn+3,[],'09-available');codecard(9,py,fn,fn+3,[],'09-observation');codecard(9,py,fn,fn+3,[fn+3],'09-reject')

    im=base(6);d=ImageDraw.Draw(im)
    wrapped(d,'TEST INPUT',620,400,1050,31,AMBER,True)
    wrapped(d,'A synthetic closure. A real routing request.',620,465,1100,45,FG,True)
    for y,a,b in [(620,'01','Actual returned detour shown'),(697,'02','Google Maps handoff blocked'),(774,'03','End test → recheck current evidence')]:
        d.text((620,y),a,font=font(27,False,True),fill=CYAN);wrapped(d,b,690,y-3,1050,32,MUTED)
    savecard(im,'06-base')
    im=base(7);d=ImageDraw.Draw(im)
    wrapped(d,'Large, persistent controls.',620,410,1100,45,FG,True)
    crop_image(im,'07-drive-active',(3,718,390,784),(620,520,1120,240))
    wrapped(d,'App audio muted beneath narration.',620,780,1100,31,MUTED)
    credit(im,'Browser demonstration · GPS off · physical-device behavior is not demonstrated')
    savecard(im,'07-base')
    im=base(8);d=ImageDraw.Draw(im)
    wrapped(d,'Simulated car · precomputed alternative',620,350,1120,30,AMBER,True)
    credit(im,'Memorial Day 2015 · archived simulation throughout · arrival note excluded')
    savecard(im,'08-base')
    im=base(8);phone_image(im,'08-current-setup');d=ImageDraw.Draw(im)
    wrapped(d,'Archived USGS observations',620,420,1120,44,FG,True)
    wrapped(d,'Memorial Day Flood 2015',620,520,1120,38,CYAN,True)
    wrapped(d,'Illustrated trip · experimental trigger\nPrecomputed alternative route',620,640,1120,33,MUTED)
    credit(im,'Actual archive setup → recorded simulation outcome')
    savecard(im,'08-setup-card')

    im=base(10);phone_image(im,'10-study');d=ImageDraw.Draw(im)
    x=620; yy=400
    d.text((x,yy),'METHOD',font=font(22,True),fill=MUTED)
    for xx,label in [(1175,'HITS'),(1395,'MISSES'),(1610,'FALSE ALARMS')]:d.text((xx,yy),label,font=font(22,True),fill=MUTED)
    d.line((620,445,1810,445),fill=LINE,width=2)
    for y,label,values in [(480,'Upstream rule',['10','2','6']),(625,'Nearest gauge',['4','8','3'])]:
        d.text((620,y+18),label,font=font(35,True),fill=FG)
        for xx,v in zip([1175,1395,1610],values): d.text((xx,y),v,font=font(72,True),fill=CYAN if xx==1175 else FG)
    wrapped(d,'12 downstream gauge-reference cases.\nRoad-flood prediction remains unvalidated.',620,790,1200,32,AMBER,True)
    credit(im,'Source: bundled LOSO results · identical values verified in the current app')
    savecard(im,'10-results')

    im=base(11,False);d=ImageDraw.Draw(im)
    d.text((90,380),'AI_USE.md',font=font(27,False,True),fill=CYAN)
    q='All code, data-pipeline scripts, tests, and documentation created or updated during these autonomous sessions are agent-authored.'
    # Exact text with Markdown emphasis removed from the real disclosure.
    ai=(REPO/'AI_USE.md').read_text(encoding='utf-8')
    assert q.replace('agent-authored.','**agent-authored**:')[:-1] in ai or 'are **agent-authored**' in ai
    wrapped(d,q,90,435,1680,37,FG)
    d.line((90,575,1830,575),fill=LINE,width=2)
    d.text((90,620),'TOOLS',font=font(23,True),fill=MUTED)
    wrapped(d,'TypeScript · JavaScript · Python · Expo',90,670,1660,42,FG,True)
    d.text((90,765),'AI ASSISTANCE',font=font(23,True),fill=MUTED)
    wrapped(d,'Claude Code + Codex',90,807,1680,39,CYAN,True)
    savecard(im,'11-disclosure')
    im=base(11,False,title='Student contributions\nIn the participants’ own words.');d=ImageDraw.Draw(im)
    d.text((90,397),'AYUSH SANKAR',font=font(23,True),fill=CYAN)
    wrapped(d,'Data organization + functionality checks',90,442,1600,47,FG,True)
    d.text((90,561),'ASHRITH REPAKA',font=font(23,True),fill=CYAN)
    wrapped(d,'Interface design for the crossing workflow',90,606,1600,47,FG,True)
    wrapped(d,'Substantial AI assistance is disclosed in AI_USE.md.',90,760,1650,31,MUTED)
    savecard(im,'11-contributions')
    im=base(12);phone_image(im,'12-map');d=ImageDraw.Draw(im)
    wrapped(d,'Next: road-level validation\nand user testing.',620,400,1150,43,MUTED)
    wrapped(d,'Obey official warnings\nand barricades.',620,580,1120,45,FG,True)
    wrapped(d,'Never drive into water.',620,775,1150,50,CYAN,True)
    savecard(im,'12-close')

def timing():
    data=json.loads((ROOT/'transcripts.json').read_text());media=json.loads((ROOT/'media.json').read_text())
    scenes=[]
    for item,meta in zip(data,media):
        words=[dict(w) for s in item['segments'] for w in s['words'] if w['end']>=w['start']]
        words=[w for w in words if not (item['scene'] in (5,6) and w['start']>=12.26)]
        a=max(0,min(w['start'] for w in words)-.18); b=min(meta['duration'],max(w['end'] for w in words)+.2)
        frames=math.ceil((b-a+.45)*FPS)
        scenes.append({'scene':item['scene'],'input':meta['file'],'trim_start':a,'trim_end':b,'frames':frames,'words':words})
    remain=165*FPS-sum(s['frames'] for s in scenes)
    weights=[1,1.2,1.2,1.4,1,1.5,1.2,1.6,1,1.5,1,1.6];total=sum(weights)
    additions=[int(remain*w/total) for w in weights]
    additions[-1]+=remain-sum(additions)
    offset=0
    for s,extra in zip(scenes,additions):
        s['frames']+=extra;s['duration']=s['frames']/FPS;s['start']=offset/FPS;offset+=s['frames'];s['voice_delay']=.22
    (ROOT/'timeline.json').write_text(json.dumps(scenes,indent=2),encoding='utf-8')
    return scenes

def audio(scenes):
    for s in scenes:
        target=SC/f"audio-{s['scene']:02d}.wav"
        if target.exists():continue
        run(['-ss',s['trim_start'],'-t',s['trim_end']-s['trim_start'],'-i',s['input'],'-vn','-af',f"highpass=f=75,afftdn=nf=-28,loudnorm=I=-16:TP=-1.5:LRA=11,afade=t=in:d=0.025,adelay=220:all=1,apad=whole_dur={s['duration']}",'-t',s['duration'],'-ar','48000','-ac','2','-c:a','pcm_s16le',target])
    concat=ROOT/'audio-concat.txt';concat.write_text('\n'.join(f"file 'scenes/audio-{s['scene']:02d}.wav'" for s in scenes))
    run(['-f','concat','-safe','0','-i',concat,'-c:a','pcm_s16le',OUT/'narration-master.wav'])

def source_clips():
    for folder in CAP.iterdir():
        info=folder/'frames.json'
        if not folder.is_dir() or not info.exists():continue
        output=SC/(folder.name+'.mp4')
        if output.exists():continue
        frames=json.loads(info.read_text());lines=[]
        for i,f in enumerate(frames):
            lines.append(f"file '{(CAP/f['file']).as_posix()}'")
            if i+1<len(frames):lines.append(f"duration {max(.001,frames[i+1]['t']-f['t']):.6f}")
        lines.append(f"file '{(CAP/frames[-1]['file']).as_posix()}'")
        manifest=folder/'concat.txt';manifest.write_text('\n'.join(lines),encoding='utf-8')
        run(['-f','concat','-safe','0','-i',manifest,'-vf','fps=30,pad=ceil(iw/2)*2:ceil(ih/2)*2','-an','-c:v','libx264','-preset','veryfast','-crf','18','-threads','3','-pix_fmt','yuv420p',output])

def still_segment(card,duration,out):
    run(['-loop','1','-framerate','30','-i',card,'-t',duration,'-an','-c:v','libx264','-preset','veryfast','-crf','20','-threads','4','-pix_fmt','yuv420p','-r','30',out])

def motion_segment(card,source,duration,out,mode='phone',seek=0):
    args=['-loop','1','-framerate','30','-i',card,'-ss',seek,'-i',source]
    if mode=='face':
        filt='[1:v]zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,format=yuv420p,scale=650:700:force_original_aspect_ratio=decrease,pad=650:700:(ow-iw)/2:(oh-ih)/2:color=0x0B111B,setsar=1,tpad=stop_mode=clone:stop_duration=30[v];[0:v][v]overlay=1120:160:shortest=1,format=yuv420p[out]'
    elif mode=='reroute':
        filt='[1:v]split=2[a][b];[a]scale=364:789,setsar=1,tpad=stop_mode=clone:stop_duration=30[p];[b]crop=392:238:0:242,scale=1130:686,setsar=1,tpad=stop_mode=clone:stop_duration=30[c];[0:v][p]overlay=134:130:shortest=1[tmp];[tmp][c]overlay=620:400:shortest=1,format=yuv420p[out]'
        # Use a smaller inset so it remains above the subtitle band.
        filt=filt.replace('scale=1130:686','scale=810:492').replace('overlay=620:400','overlay=770:402')
    else:
        filt='[1:v]scale=364:789,setsar=1,tpad=stop_mode=clone:stop_duration=30[p];[0:v][p]overlay=134:130:shortest=1,format=yuv420p[out]'
    run([*args,'-filter_complex',filt,'-map','[out]','-an','-t',duration,'-c:v','libx264','-preset','veryfast','-crf','20','-threads','4','-filter_complex_threads','2','-r','30',out])

def scene_videos(scenes):
    for s in scenes:
        n=s['scene'];dur=s['duration'];parts=[]
        def still(key,t):
            out=SC/f'part-{n:02d}-{len(parts)}.mp4';still_segment(SC/f'{key}.png',t,out);parts.append(out)
        def motion(key,clip,t,mode='phone',seek=0):
            out=SC/f'part-{n:02d}-{len(parts)}.mp4';motion_segment(SC/f'{key}.png',clip,t,out,mode,seek);parts.append(out)
        final=SC/f'scene-{n:02d}.mp4'
        if final.exists(): continue
        if n==1:motion('01-intro-base',SRC/'scene-01.mov',4.2,'face');still('01-map-card',dur-4.2)
        elif n==2:still('02-context',4.7);still('02-notice',5.5);still('02-app',dur-10.2)
        elif n==3:motion('03-base',SC/'03-route-loading.mp4',dur)
        elif n==4:still('04-evidence',dur*.58);still('04-groups',dur*.42)
        elif n==5:still('05-road',dur*.35);still('05-waterway',dur*.30);still('05-distance',dur*.35)
        elif n==6:
            weights=[.13,.27,.20,.13,.27]; clips=['06-tools','06-test','06-test-map',None,'06-end-test']
            for clip,w in zip(clips,weights):
                if clip:motion('06-base',SC/f'{clip}.mp4',dur*w)
                else:
                    im=Image.open(SC/'06-base.png');phone_image(im,'06-navigation-blocked');savecard(im,'06-locked-card');still('06-locked-card',dur*w)
        elif n==7:motion('07-base',SC/'07-drive.mp4',dur)
        elif n==8:still('08-setup-card',2.6);motion('08-base',SC/'08-reroute.mp4',dur-2.6,'reroute')
        elif n==9:still('09-available',dur*.32);still('09-observation',dur*.32);still('09-reject',dur*.36)
        elif n==10:still('10-results',dur)
        elif n==11:still('11-disclosure',dur*.48);still('11-contributions',dur*.52)
        elif n==12:still('12-close',dur)
        concat=SC/f'scene-{n:02d}-concat.txt';concat.write_text('\n'.join(f"file '{p.as_posix()}'" for p in parts))
        run(['-f','concat','-safe','0','-i',concat,'-t',dur,'-an','-c','copy',final])
        print('Rendered scene',n,round(dur,3),flush=True)
    master=ROOT/'video-concat.txt';master.write_text('\n'.join(f"file 'scenes/scene-{s['scene']:02d}.mp4'" for s in scenes))
    run(['-f','concat','-safe','0','-i',master,'-c','copy','-an',OUT/'picture-master.mp4'])

def subtitles(scenes):
    replacements={'Forecast':'FordCast','forecast':'FordCast','Fordcast':'FordCast','forecasts':'FordCast','Cloud':'Claude','CodeX':'Codex','infiltrating':'inflating','Auschwitz':'Ashrith','Ashut':'Ashrith'}
    events=[]
    for s in scenes:
        words=s['words'];group=[]
        def flush():
            if not group:return
            txt=' '.join(w['word'].strip() for w in group)
            for a,b in replacements.items():txt=re.sub(r'\b'+re.escape(a)+r'\b',b,txt)
            txt=txt.replace('A bay official','Obey official').replace('warnings in barricades','warnings and barricades')
            txt=txt.replace('groups It improves hardware','groups hardware').replace('groups It hardware','groups hardware')
            txt=txt.replace('low -water','low-water').replace('central Texas','Central Texas')
            txt=txt.replace('pre -computed','precomputed').replace('repeat mute and stop','repeat, mute, and stop')
            txt=txt.replace('2052 inventory','2,052 inventory').replace('road flood prediction','road-flood prediction')
            # Proper-name spelling is reviewable separately; no invented student surname is added.
            a=s['start']+group[0]['start']-s['trim_start']+.22
            b=s['start']+group[-1]['end']-s['trim_start']+.22
            events.append((a,b,txt))
        for w in words:
            candidate=' '.join(x['word'].strip() for x in [*group,w])
            if group and (len(candidate)>82 or w['end']-group[0]['start']>4.1):flush();group=[]
            group.append(w)
            if w['word'].strip().endswith(('.', '?', '!')):flush();group=[]
        flush()
    def stamp(t,ass=False):
        if ass:
            cs=int(round(t*100));return f'{cs//360000}:{cs//6000%60:02}:{cs//100%60:02}.{cs%100:02}'
        ms=int(round(t*1000));return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
    srt=[];ass=['[Script Info]','ScriptType: v4.00+','PlayResX: 1920','PlayResY: 1080','WrapStyle: 0','','[V4+ Styles]','Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding','Style: Default,Segoe UI,36,&H00F7F3EC,&H000000FF,&H00130C07,&H00130C07,0,0,0,0,100,100,0,0,1,1,0,2,100,100,35,1','','[Events]','Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text']
    for i,(a,b,txt) in enumerate(events,1):
        lines=textwrap.wrap(txt,76); text='\n'.join(lines)
        srt.append(f'{i}\n{stamp(a)} --> {stamp(b)}\n{text}\n')
        ass.append(f"Dialogue: 0,{stamp(a,True)},{stamp(b,True)},Default,,0,0,0,,"+text.replace('\n',r'\N'))
    (OUT/'FordCast_Captions.srt').write_text('\n'.join(srt),encoding='utf-8')
    (ROOT/'captions.ass').write_text('\n'.join(ass),encoding='utf-8-sig')

if __name__=='__main__':
    task=sys.argv[1] if len(sys.argv)>1 else 'all'
    scenes=timing()
    if task in ['audio','all']:audio(scenes)
    if task in ['clips','all']:source_clips()
    if task in ['cards','all']:cards()
    if task in ['render','all']:scene_videos(scenes)
    if task in ['finish','all']:
        subtitles(scenes)
        run(['-i',OUT/'picture-master.mp4','-i',OUT/'narration-master.wav','-vf','ass=captions.ass','-map','0:v','-map','1:a','-t','165','-c:v','libx264','-preset','fast','-crf','20','-threads','6','-c:a','aac','-b:a','192k','-ar','48000','-movflags','+faststart','-pix_fmt','yuv420p',OUT/'FordCast_Demo_1080p.mp4'])
        print('Finished',OUT/'FordCast_Demo_1080p.mp4',flush=True)
